//@line 37 "/macpro/Development/moz1.9.2/src/toolkit/mozapps/extensions/content/eula.js"

function Startup() {
  var bundle = document.getElementById("extensionsStrings");
  var label = document.createTextNode(bundle.getFormattedString("eulaHeader", [window.arguments[0].name]));
  document.getElementById("heading").appendChild(label);
  document.getElementById("eula").value = window.arguments[0].text;
}
