//@line 38 "/macpro/Development/moz1.9.2/src/prism/chrome/content/preferences/securityWarnings.js"

function secWarningSyncTo(aEvent) {
  var prefName = aEvent.target.getAttribute("preference") + ".show_once";
  var prefOnce = document.getElementById(prefName);
  prefOnce.value = false;
  return undefined;    
}
