// Copyright (c) 2000-2011 Quadralay Corporation.  All rights reserved.
//

// Search complete
//
WWHFrame.WWHSearch.fCheckForPhraseMatch(FileData_Pairs);
