//@line 38 "/home/hudson/workdir/mozilla/192src/prism/chrome/content/preferences/securityWarnings.js"

function secWarningSyncTo(aEvent) {
  var prefName = aEvent.target.getAttribute("preference") + ".show_once";
  var prefOnce = document.getElementById(prefName);
  prefOnce.value = false;
  return undefined;    
}
