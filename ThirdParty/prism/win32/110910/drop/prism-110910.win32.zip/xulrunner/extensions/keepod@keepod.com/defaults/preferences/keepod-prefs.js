pref("dom.max_script_run_time", 0);
pref("dom.max_chrome_script_run_time", 0);