function  WWHBookData_AddIndexEntries(P)
{
}

function  WWHBookData_MaxIndexLevel()
{
  return 0;
}
