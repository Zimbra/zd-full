function  WWHToWWHelpDirectory()
{
  return "";
}
