// Copyright (c) 2000-2011 Quadralay Corporation.  All rights reserved.
//

// Increment book index
//
WWHFrame.WWHSearch.mBookIndex++;
