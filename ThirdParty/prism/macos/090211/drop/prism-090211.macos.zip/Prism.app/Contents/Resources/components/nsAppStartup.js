/*
//@line 39 "/Users/hudson/workdir/mozilla/192src/prism/components/src/nsAppStartup.js"
*/

/* Development of this Contribution was supported by Yahoo! Inc. */

const Cc = Components.classes;
const Ci = Components.interfaces;

Components.utils.import("resource://gre/modules/XPCOMUtils.jsm");

function AppStartup() {
}

AppStartup.prototype = {
  classDescription: "Application initialization",
  classID:          Components.ID("{54683c67-7e7c-444e-a9f7-bb47fe42d828}"),
  contractID:       "@mozilla.org/prism-app-startup;1",

  _xpcom_categories : [
    { category: "app-startup", service: true }
  ],

  QueryInterface: XPCOMUtils.generateQI(
    [Ci.nsIObserver,
     Ci.nsIClassInfo]),

  // nsIClassInfo
  implementationLanguage: Ci.nsIProgrammingLanguage.JAVASCRIPT,
  flags: Ci.nsIClassInfo.DOM_OBJECT,

  getInterfaces: function getInterfaces(aCount) {
    var interfaces = [Ci.nsIObserver,
                      Ci.nsIClassInfo];
    aCount.value = interfaces.length;
    return interfaces;
  },

  getHelperForLanguage: function getHelperForLanguage(aLanguage) {
    return null;
  },

  //nsIObserver
  observe: function (aSubject, aTopic, aData) {
    switch (aTopic) {
    case "app-startup":
      var ios = Cc["@mozilla.org/network/io-service;1"].getService(Ci.nsIIOService);
      var resourceProtocol = ios.getProtocolHandler("resource").QueryInterface(Ci.nsIResProtocolHandler);
      
      var environment = Cc["@mozilla.org/process/environment;1"].getService(Ci.nsIEnvironment);
      var rootPath = environment.get("PRISM_APP_BUNDLE");
      var resourcesRoot = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsILocalFile);
      resourcesRoot.initWithPath(rootPath);
      
      resourceProtocol.setSubstitution("appbundle", ios.newFileURI(resourcesRoot));
      break;
    }
  },
}

var components = [AppStartup];

function NSGetModule(compMgr, fileSpec) {
  return XPCOMUtils.generateModule(components);
}
